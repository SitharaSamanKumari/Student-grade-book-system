package com.inovaItSys.app.db;

import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

class GradeDataAccessTest {

//    @Test
//    void getResultGrade() throws SQLException {
//        assertTrue(GradeDataAccess.getResultGrade(100).equals("A+"));
//    }
}