package com.inovaItSys.app;

import java.sql.SQLException;

public class AppInitializerWrapper {
    public static void main(String[] args) throws SQLException {
        AppInitializer.main(args);
    }
}
